package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.ChatMessage
import com.example.data.database.ChatSession
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val chatDao = AppDatabase.getDatabase(application).chatDao()
    private val repository = ChatRepository(chatDao)

    // Current selected session, null means user has not selected or started any chat yet
    private val _currentSessionId = MutableStateFlow<Int?>(null)
    val currentSessionId: StateFlow<Int?> = _currentSessionId.asStateFlow()

    // Flag for api request loading status
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Input text in bottom field
    val inputText = MutableStateFlow("")

    // List of all conversations to show in the history sidebar drawer
    val sessions: StateFlow<List<ChatSession>> = repository.allSessions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current messages updates reactively when currentSessionId changes
    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<ChatMessage>> = _currentSessionId
        .flatMapLatest { sessionId ->
            if (sessionId != null) {
                repository.getMessagesForSession(sessionId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // Auto-select or create first chat session if lists are empty
        viewModelScope.launch {
            sessions.collectLatest { sessionList ->
                if (_currentSessionId.value == null && sessionList.isNotEmpty()) {
                    _currentSessionId.value = sessionList.first().id
                }
            }
        }
    }

    fun selectSession(sessionId: Int) {
        _currentSessionId.value = sessionId
    }

    fun startNewChat() {
        viewModelScope.launch {
            val dbId = repository.createNewSession()
            _currentSessionId.value = dbId
            inputText.value = ""
        }
    }

    fun deleteSession(sessionId: Int) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                _currentSessionId.value = sessions.value.firstOrNull()?.id
            }
        }
    }

    fun sendMessage() {
        val query = inputText.value.trim()
        if (query.isEmpty() || _isLoading.value) return

        inputText.value = ""
        _isLoading.value = true

        viewModelScope.launch {
            var sessionId = _currentSessionId.value
            if (sessionId == null) {
                // Instantly create a new session if none is pre-selected
                sessionId = repository.createNewSession()
                _currentSessionId.value = sessionId
            }

            try {
                repository.sendMessage(sessionId, query)
            } catch (e: Exception) {
                // Fallback inside repository or viewmodel
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun sendPresetPrompt(promptText: String) {
        inputText.value = promptText
        sendMessage()
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
                return ChatViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
