package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// ChatGPT-inspired Theme Palette
val ChatGptBackground = Color(0xFF171717)
val ChatGptBackgroundDark = Color(0xFF0D0D0D)
val ChatGptSurface = Color(0xFF212121)
val ChatGptAccent = Color(0xFF10A37F) // ChatGPT Mint Teal
val ChatGptUserBubble = Color(0xFF2F2F2F)
val ChatGptTextPrimary = Color(0xFFECECEC)
val ChatGptTextSecondary = Color(0xFFB4B4B4)
val ChatGptRipple = Color(0xFF3C3C3C)
