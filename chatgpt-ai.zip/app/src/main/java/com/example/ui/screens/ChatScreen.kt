package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.ChatMessage
import com.example.data.database.ChatSession
import com.example.ui.ChatViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val sessions by viewModel.sessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val inputText by viewModel.inputText.collectAsState()

    // Keep track of side navigation drawer toggle
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = ChatGptBackgroundDark,
                modifier = Modifier.width(300.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 24.dp)
                ) {
                    // Header/Logo
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 24.dp, top = 16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(ChatGptAccent),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "AI",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ChatGPT AI",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Powered by Gemini 3.5",
                                color = ChatGptTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // "New Chat" Button in Drawer
                    Button(
                        onClick = {
                            viewModel.startNewChat()
                            coroutineScope.launch { drawerState.close() }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ChatGptUserBubble),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "New Chat", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("New Chat", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }

                    // Divider
                    HorizontalDivider(color = Color(0xFF222222), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Recent Conversations",
                        color = ChatGptTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // Previous Session Chat History list
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(sessions) { session ->
                            val isSelected = session.id == currentSessionId
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) ChatGptUserBubble else Color.Transparent)
                                    .clickable {
                                        viewModel.selectSession(session.id)
                                        coroutineScope.launch { drawerState.close() }
                                    }
                                    .padding(vertical = 10.dp, horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.ChatBubbleOutline,
                                    contentDescription = "Chat",
                                    tint = if (isSelected) ChatGptAccent else ChatGptTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = session.title,
                                    color = if (isSelected) Color.White else ChatGptTextPrimary,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )
                                // Delete conversation button
                                IconButton(
                                    onClick = { viewModel.deleteSession(session.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = ChatGptTextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Sidebar Footer
                    HorizontalDivider(color = Color(0xFF222222), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = ChatGptTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Settings & Preferences",
                            color = ChatGptTextPrimary,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        },
        content = {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            val activeSession = sessions.find { it.id == currentSessionId }
                            Text(
                                text = activeSession?.title ?: "ChatGPT AI",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.White)
                            }
                        },
                        actions = {
                            // Quick Action to Start New Chat
                            IconButton(onClick = { viewModel.startNewChat() }) {
                                Icon(Icons.Default.AddComment, contentDescription = "New Chat", tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ChatGptBackgroundDark
                        )
                    )
                },
                containerColor = ChatGptBackground,
                modifier = modifier.fillMaxSize()
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    val listState = rememberLazyListState()

                    // Auto scroll list when new messages or typing indicator reveals
                    LaunchedEffect(messages.size, isLoading) {
                        if (messages.isNotEmpty()) {
                            listState.animateScrollToItem(messages.size - 1)
                        }
                    }

                    // If no conversations exist or history is empty, show modern ChatGPT centered Welcome home
                    if (messages.isEmpty() && !isLoading) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Beautiful geometric custom ChatGPT-style logo built in canvas
                                ChatGPTVisualLogo()

                                Spacer(modifier = Modifier.height(20.dp))

                                Text(
                                    text = "How can I help you today?",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(40.dp))

                                // Quick suggestion templates layout
                                Text(
                                    text = "Presets & Ideas",
                                    color = ChatGptTextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .align(Alignment.Start)
                                        .padding(bottom = 12.dp)
                                )

                                Column(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    PresetPromptRow(
                                        title = "💡 Idea Storming",
                                        hint = "Give me 5 unique names for a coffee shop with sci-fi theme",
                                        onClick = { viewModel.sendPresetPrompt(it) }
                                    )
                                    PresetPromptRow(
                                        title = "✍️ Professional Email",
                                        hint = "Write an apology email to a client for project delay in professional tone",
                                        onClick = { viewModel.sendPresetPrompt(it) }
                                    )
                                    PresetPromptRow(
                                        title = "💻 Code Explanation",
                                        hint = "Explain recursion in Kotlin containing simple example code",
                                        onClick = { viewModel.sendPresetPrompt(it) }
                                    )
                                    PresetPromptRow(
                                        title = "🚀 Study Plan Builder",
                                        hint = "Create a 3-day rapid study roadmap for deep learning basics",
                                        onClick = { viewModel.sendPresetPrompt(it) }
                                    )
                                }
                            }
                        }
                    } else {
                        // Show conversational log
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(messages) { message ->
                                ChatMessageItem(message = message)
                            }

                            // Pulsing dot animations for Gemini model generating reply response
                            if (isLoading) {
                                item {
                                    GeminiTypingIndicator()
                                }
                            }
                        }
                    }

                    // Input Field capsule & disclaimer
                    MessageInputBar(
                        inputText = inputText,
                        onTextChange = { viewModel.inputText.value = it },
                        onSendClick = { viewModel.sendMessage() },
                        isLoading = isLoading
                    )
                }
            }
        }
    )
}

/**
 * Beautiful geometric Custom ChatGPT style Vector Logo rendered using Compose Canvas
 */
@Composable
fun ChatGPTVisualLogo() {
    Canvas(
        modifier = Modifier
            .size(80.dp)
            .border(2.dp, ChatGptAccent.copy(alpha = 0.5f), CircleShape)
            .padding(16.dp)
    ) {
        val radius = size.minDimension / 2f
        val center = size / 2f

        // Draw 6 symmetrical soft circles forming ChatGPT's famous spiral/flower logo geometry
        val angles = listOf(0f, 60f, 120f, 180f, 240f, 300f)
        for (angle in angles) {
            val radians = Math.toRadians(angle.toDouble())
            val offsetRadius = radius * 0.45f
            val circleCenterX = center.width + (offsetRadius * Math.cos(radians)).toFloat()
            val circleCenterY = center.height + (offsetRadius * Math.sin(radians)).toFloat()

            drawCircle(
                color = ChatGptAccent.copy(alpha = 0.8f),
                radius = radius * 0.45f,
                center = androidx.compose.ui.geometry.Offset(circleCenterX, circleCenterY)
            )
        }
        // Core highlight
        drawCircle(
            color = Color.White,
            radius = radius * 0.25f,
            center = androidx.compose.ui.geometry.Offset(center.width, center.height)
        )
    }
}

/**
 * Preset suggestion bar
 */
@Composable
fun PresetPromptRow(
    title: String,
    hint: String,
    onClick: (String) -> Unit
) {
    Card(
        onClick = { onClick(hint) },
        colors = CardDefaults.cardColors(
            containerColor = ChatGptSurface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF2E2E2E), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    text = hint,
                    color = ChatGptTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Icon(
                Icons.Default.ArrowOutward,
                contentDescription = "Send",
                tint = ChatGptAccent,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

/**
 * Chat log item bubble
 */
@Composable
fun ChatMessageItem(message: ChatMessage) {
    val isUser = message.role == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            // Mini stylized ChatGPT profile icon next to assistant reply
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ChatGptAccent),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = "Model",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
        }

        // Message text bubble
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(if (isUser) ChatGptUserBubble else Color.Transparent)
                .border(
                    width = if (isUser) Constants.BorderWidthUser else 0.dp,
                    color = if (isUser) Color(0xFF3E3E3E) else Color.Transparent,
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            if (isUser) {
                Text(
                    text = message.text,
                    color = Color.White,
                    fontSize = 15.sp,
                    lineHeight = 20.sp
                )
            } else {
                // Parse markdown-styled replies from assistant
                MarkdownReplyContent(rawMessage = message.text)
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(4.dp))
        }
    }
}

/**
 * Simple parser displaying markdown text or stylized code listings in a gorgeous slate block
 */
@Composable
fun MarkdownReplyContent(rawMessage: String) {
    val blocks = remember(rawMessage) { parseMarkdownBlocks(rawMessage) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (block in blocks) {
            if (block.isCode) {
                // Code block with monospace typography styled like ChatGPT
                Card(
                    colors = CardDefaults.cardColors(containerColor = ChatGptBackgroundDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF2A2A2A), RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                        ) {
                            Text(
                                text = block.codeLanguage,
                                color = ChatGptTextSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Code Block",
                                color = ChatGptAccent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = block.content,
                            color = Color(0xFFA9FFB4), // light green-ish code highlight
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            } else {
                // Ordinary text with bullet list support
                Text(
                    text = block.content,
                    color = ChatGptTextPrimary,
                    fontSize = 15.sp,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

data class MarkdownBlock(
    val content: String,
    val isCode: Boolean,
    val codeLanguage: String = "code"
)

fun parseMarkdownBlocks(text: String): List<MarkdownBlock> {
    if (!text.contains("```")) {
        return listOf(MarkdownBlock(content = text, isCode = false))
    }

    val blocks = mutableListOf<MarkdownBlock>()
    val segments = text.split("```")
    for (i in segments.indices) {
        val segment = segments[i]
        if (i % 2 == 1) {
            // This segment lies inside backticks
            val lines = segment.split("\n")
            val language = lines.firstOrNull()?.trim() ?: "code"
            val codeBody = if (lines.size > 1) {
                lines.drop(1).joinToString("\n").trim()
            } else {
                segment.trim()
            }
            blocks.add(MarkdownBlock(content = codeBody, isCode = true, codeLanguage = language.ifBlank { "code" }))
        } else {
            if (segment.isNotEmpty()) {
                blocks.add(MarkdownBlock(content = segment, isCode = false))
            }
        }
    }
    return blocks
}

/**
 * Custom pulsing dot typing indicator
 */
@Composable
fun GeminiTypingIndicator() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(ChatGptAccent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.AutoAwesome,
                contentDescription = "Model",
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = ChatGptUserBubble.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.padding(vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Analyzing with Flash ", color = ChatGptTextSecondary, fontSize = 12.sp)
                PulseDot(delay = 0)
                PulseDot(delay = 200)
                PulseDot(delay = 400)
            }
        }
    }
}

@Composable
fun PulseDot(delay: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
            initialStartOffset = StartOffset(offsetMillis = delay)
        ),
        label = "dotsScale"
    )

    Box(
        modifier = Modifier
            .size(6.dp)
            .clip(CircleShape)
            .background(ChatGptAccent.copy(alpha = scale))
    )
}

/**
 * Message Input capsule with clean M3 icons and disclaimer
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageInputBar(
    inputText: String,
    onTextChange: (String) -> Unit,
    onSendClick: () -> Unit,
    isLoading: Boolean
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(ChatGptBackground)
            .padding(horizontal = 12.dp)
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Round capsule styled Input field
            TextField(
                value = inputText,
                onValueChange = onTextChange,
                placeholder = {
                    Text(
                        text = if (isLoading) "Generating reply..." else "Message",
                        color = ChatGptTextSecondary
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(26.dp))
                    .border(1.dp, Color(0xFF2F2F2F), RoundedCornerShape(26.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = ChatGptUserBubble,
                    unfocusedContainerColor = ChatGptUserBubble,
                    disabledContainerColor = ChatGptUserBubble,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                maxLines = 4,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputText.isNotBlank() && !isLoading) {
                            onSendClick()
                            keyboardController?.hide()
                        }
                    }
                ),
                leadingIcon = {
                    Icon(
                        Icons.Default.Language,
                        contentDescription = "Globe Icon",
                        tint = ChatGptTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    Row(modifier = Modifier.padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { /* Simulated Voice Input indicator */ }) {
                            Icon(
                                Icons.Default.KeyboardVoice,
                                contentDescription = "Voice prompt",
                                tint = ChatGptTextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Round solid button holding Arrow upward submit, matches ChatGPT mobile exactly!
            IconButton(
                onClick = {
                    onSendClick()
                    keyboardController?.hide()
                },
                enabled = inputText.isNotBlank() && !isLoading,
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (inputText.isNotBlank() && !isLoading) ChatGptAccent else ChatGptUserBubble
                    )
            ) {
                Icon(
                    Icons.Default.ArrowUpward,
                    contentDescription = "Send text",
                    tint = if (inputText.isNotBlank() && !isLoading) Color.White else ChatGptTextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Disclaimer at the very bottom fine print
        Text(
            text = "ChatGPT AI can make mistakes. Check important info.",
            color = ChatGptTextSecondary.copy(alpha = 0.8f),
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        )
    }
}

object Constants {
    val BorderWidthUser = 1.dp
}
