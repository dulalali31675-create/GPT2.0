package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val ChatGptDarkColorScheme = darkColorScheme(
    primary = ChatGptAccent,
    secondary = ChatGptUserBubble,
    tertiary = ChatGptAccent,
    background = ChatGptBackground,
    surface = ChatGptSurface,
    onPrimary = Color.White,
    onSecondary = ChatGptTextPrimary,
    onTertiary = Color.White,
    onBackground = ChatGptTextPrimary,
    onSurface = ChatGptTextPrimary,
    surfaceVariant = ChatGptUserBubble,
    onSurfaceVariant = ChatGptTextPrimary
)

private val ChatGptLightColorScheme = lightColorScheme(
    primary = ChatGptAccent,
    secondary = Color(0xFFF3F3F3),
    tertiary = ChatGptAccent,
    background = Color.White,
    surface = Color(0xFFF9F9F9),
    onPrimary = Color.White,
    onSecondary = Color(0xFF171717),
    onTertiary = Color.White,
    onBackground = Color(0xFF171717),
    onSurface = Color(0xFF171717),
    surfaceVariant = Color(0xFFE5E5E5),
    onSurfaceVariant = Color(0xFF171717)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme by default like ChatGPT Play Store style!
    dynamicColor: Boolean = false, // Disable to preserve iconic ChatGPT branding colors!
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) ChatGptDarkColorScheme else ChatGptLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
