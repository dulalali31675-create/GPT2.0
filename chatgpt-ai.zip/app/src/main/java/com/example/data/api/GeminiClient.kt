package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.database.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateChatResponse(history: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "API Key is missing or default placeholder!")
            return@withContext "Error: API Key is missing. Please add your GEMINI_API_KEY to the AI Studio Secrets panel."
        }

        try {
            // Build request object
            val rootJson = JSONObject()
            val contentsArray = JSONArray()

            for (msg in history) {
                val turnJson = JSONObject()
                // Map DB roles to Gemini API roles: "user" -> "user", "assistant" -> "model"
                val apiRole = if (msg.role == "assistant") "model" else "user"
                turnJson.put("role", apiRole)

                val partsArray = JSONArray()
                val partJson = JSONObject()
                partJson.put("text", msg.text)
                partsArray.put(partJson)

                turnJson.put("parts", partsArray)
                contentsArray.put(turnJson)
            }
            rootJson.put("contents", contentsArray)

            // Add system instructions
            val systemInstructionJson = JSONObject()
            val sysPartsArray = JSONArray()
            sysPartsArray.put(JSONObject().put("text", "You are a helpful, super polite, and intelligent AI assistant. You must give clean, beautiful Markdown formatted replies with high resolution, bolding, listings, or code blocks where appropriate. Pretend to be a sleek chat companion tailored for mobile screens, matching the ChatGPT experience perfectly."))
            systemInstructionJson.put("parts", sysPartsArray)
            rootJson.put("systemInstruction", systemInstructionJson)

            val requestBody = rootJson.toString().toRequestBody("application/json".toMediaType())

            val url = "$BASE_URL?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .header("Content-Type", "application/json")
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string()
                if (!response.isSuccessful) {
                    Log.e(TAG, "API failed: Code ${response.code}, Body: $bodyString")
                    return@withContext "Error: Call failed with status ${response.code}. Please ensure your API key is valid."
                }

                if (bodyString.isNullOrEmpty()) {
                    return@withContext "Error: Empty response body received."
                }

                val responseJson = JSONObject(bodyString)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    if (contentObj != null) {
                        val parts = contentObj.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "No text part received.")
                        }
                    }
                }
                return@withContext "Error: Unable to parse reply content."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during call", e)
            return@withContext "Exception: ${e.message ?: "Unknown error"}. Check internet connection or settings."
        }
    }
}
