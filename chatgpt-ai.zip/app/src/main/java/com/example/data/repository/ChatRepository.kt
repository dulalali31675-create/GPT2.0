package com.example.data.repository

import com.example.data.api.GeminiClient
import com.example.data.database.ChatDao
import com.example.data.database.ChatMessage
import com.example.data.database.ChatSession
import kotlinx.coroutines.flow.Flow

class ChatRepository(private val chatDao: ChatDao) {

    val allSessions: Flow<List<ChatSession>> = chatDao.getAllSessionsFlow()

    fun getMessagesForSession(sessionId: Int): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForSessionFlow(sessionId)
    }

    suspend fun createNewSession(initialTitle: String = "New Chat"): Int {
        val session = ChatSession(title = initialTitle)
        return chatDao.insertSession(session).toInt()
    }

    suspend fun deleteSession(sessionId: Int) {
        val session = ChatSession(id = sessionId, title = "")
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(session)
    }

    suspend fun sendMessage(sessionId: Int, userText: String): String {
        // 1. Save user's message
        val userMsg = ChatMessage(sessionId = sessionId, role = "user", text = userText)
        chatDao.insertMessage(userMsg)

        // 2. Fetch full conversation history
        val history = chatDao.getMessagesForSession(sessionId)

        // 3. Auto-update session title if it is "New Chat" and this is the first user query
        if (history.size <= 2) {
            val words = userText.trim().split("\\s+".toRegex())
            val title = if (words.size > 5) {
                words.take(5).joinToString(" ") + "..."
            } else {
                userText.trim()
            }
            if (title.isNotEmpty()) {
                val currentSession = ChatSession(id = sessionId, title = title)
                chatDao.updateSession(currentSession)
            }
        }

        // 4. Send background context request to Gemini
        val assistantReply = GeminiClient.generateChatResponse(history)

        // 5. Save assistant reply in database
        val assistantMsg = ChatMessage(sessionId = sessionId, role = "assistant", text = assistantReply)
        chatDao.insertMessage(assistantMsg)

        return assistantReply
    }
}
